
import React from 'react';
import './Footer.css';

const Footer: React.FC = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-info">
            <h3>Peekaboo Interactive</h3>
            <p>Making calm, educational experiences for toddlers since 2008.</p>
            <p>© {new Date().getFullYear()} Peekaboo Studios LLC. All rights reserved.</p>
          </div>
          
          <div className="footer-links">
            <div className="footer-column">
              <h4>Apps</h4>
              <ul>
                <li><a href="https://apps.apple.com/us/app/peekaboo-plunk/id6749132469" target="_blank" rel="noopener noreferrer">Peekaboo Plunk</a></li>
                <li><a href="https://apps.apple.com/us/app/peekaboo-calm/id6748668506" target="_blank" rel="noopener noreferrer">Peekaboo Calm</a></li>
                <li><a href="https://www.peekaboo.mobi/" target="_blank" rel="noopener noreferrer">More Apps</a></li>
              </ul>
            </div>
            
            <div className="footer-column">
              <h4>Connect</h4>
              <ul>
                <li><a href="https://apps.apple.com/us/developer/bhhc-llc/id1808485512" target="_blank" rel="noopener noreferrer">App Store</a></li>
                <li><a href="https://www.linkedin.com/company/peekaboo-studios" target="_blank" rel="noopener noreferrer">LinkedIn</a></li>
              </ul>
            </div>
            
            <div className="footer-column">
              <h4>Support</h4>
              <ul>
                <li><a href="mailto:support@peekaboostudiosllc.com">support@peekaboostudiosllc.com</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
