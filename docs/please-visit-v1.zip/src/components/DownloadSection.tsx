
import React from 'react';
import './DownloadSection.css';

const DownloadSection: React.FC = () => {
  return (
    <section className="download-section">
      <div className="container">
        <div className="download-content">
          <h2>Start Calm Playtime Today</h2>
          <p>
            Give your child the gift of peaceful exploration. Download both apps 
            and discover the joy of gentle, educational interactions.
          </p>
          <div className="download-buttons">
            <a 
              href="https://apps.apple.com/us/app/peekaboo-plunk/id6749132469" 
              className="btn"
              target="_blank"
              rel="noopener noreferrer"
            >
              Download Peekaboo Plunk
            </a>
            <a 
              href="https://apps.apple.com/us/app/peekaboo-calm/id6748668506" 
              className="btn btn-secondary"
              target="_blank"
              rel="noopener noreferrer"
            >
              Download Peekaboo Calm
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DownloadSection;
