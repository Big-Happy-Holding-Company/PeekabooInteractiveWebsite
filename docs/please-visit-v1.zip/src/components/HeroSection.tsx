
import React from 'react';
import './HeroSection.css';

const HeroSection: React.FC = () => {
  return (
    <section className="hero">
      <div className="hero-content">
        <h1>Calming Interactive Experiences for Toddlers</h1>
        <p className="hero-subtitle">
          Gentle, educational apps designed for sensory-sensitive children aged 0–4. 
          No ads, no scores, no pressure—just peaceful discovery.
        </p>
        <div className="hero-buttons">
          <a 
            href="https://apps.apple.com/us/app/peekaboo-plunk/id6749132469" 
            className="btn"
            target="_blank"
            rel="noopener noreferrer"
          >
            Try Peekaboo Plunk
          </a>
          <a 
            href="https://apps.apple.com/us/app/peekaboo-calm/id6748668506" 
            className="btn btn-secondary"
            target="_blank"
            rel="noopener noreferrer"
          >
            Try Peekaboo Calm
          </a>
        </div>
      </div>
      <div className="hero-image">
        <div className="app-preview">
          <div className="app-preview-item">
            <div className="app-icon calm"></div>
            <p>Peekaboo Calm</p>
          </div>
          <div className="app-preview-item">
            <div className="app-icon plunk"></div>
            <p>Peekaboo Plunk</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
