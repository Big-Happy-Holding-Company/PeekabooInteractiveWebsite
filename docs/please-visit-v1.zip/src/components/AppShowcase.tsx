
import React from 'react';
import './AppShowcase.css';

const AppShowcase: React.FC = () => {
  return (
    <section className="app-showcase">
      <div className="container">
        <h2 className="section-title">Meet Our Apps</h2>
        <p className="section-subtitle">
          Two calming experiences, one gentle philosophy
        </p>
        
        <div className="app-cards">
          <div className="app-card">
            <div className="app-icon large calm"></div>
            <div className="app-content">
              <h3>Peekaboo Calm</h3>
              <p>
                A serene underwater world where gentle sea creatures respond to your child's touch. 
                Watch jellyfish pulse, kelp sway, and bubbles rise in this tranquil ocean experience.
              </p>
              <ul>
                <li>Interactive marine life diorama</li>
                <li>Soft watercolor visuals</li>
                <li>Underwater soundscapes</li>
                <li>Personal voice recording</li>
              </ul>
              <a 
                href="https://apps.apple.com/us/app/peekaboo-calm/id6748668506" 
                className="btn"
                target="_blank"
                rel="noopener noreferrer"
              >
                Download Now
              </a>
            </div>
          </div>
          
          <div className="app-card">
            <div className="app-icon large plunk"></div>
            <div className="app-content">
              <h3>Peekaboo Plunk</h3>
              <p>
                A whimsical treehouse world where colorful balls bounce, tumble, and plunk through 
                playful contraptions. Engage with spinning wheels, rolling tubes, and musical chimes.
              </p>
              <ul>
                <li>Interactive physics playground</li>
                <li>Bright, cheerful color palette</li>
                <li>Gentle plunking sounds</li>
                <li>Personal voice recording</li>
              </ul>
              <a 
                href="https://apps.apple.com/us/app/peekaboo-plunk/id6749132469" 
                className="btn"
                target="_blank"
                rel="noopener noreferrer"
              >
                Download Now
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AppShowcase;
