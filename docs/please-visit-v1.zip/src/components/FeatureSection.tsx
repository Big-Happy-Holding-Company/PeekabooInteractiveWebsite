
import React from 'react';
import './FeatureSection.css';

const features = [
  {
    title: "Sensory-Friendly Design",
    description: "Gentle visuals, soft sounds, and large touch areas designed specifically for sensory-sensitive children.",
    icon: "🎨"
  },
  {
    title: "Educational Discovery",
    description: "Interactive physics-based dioramas that teach cause and effect through playful exploration.",
    icon: "📚"
  },
  {
    title: "Personalized Experience",
    description: "Record your own voice to create a cozy, familiar play environment for your child.",
    icon: "🎙️"
  },
  {
    title: "Peaceful Playtime",
    description: "No ads, no scores, no timers - just calm, self-directed exploration at your child's pace.",
    icon: "😴"
  }
];

const FeatureSection: React.FC = () => {
  return (
    <section className="features">
      <div className="container">
        <h2 className="section-title">Thoughtfully Designed for Toddlers</h2>
        <p className="section-subtitle">
          Our apps create the perfect environment for calm, educational play during 
          bedtime wind-down, transitions, and on-the-go breaks.
        </p>
        
        <div className="features-grid">
          {features.map((feature, index) => (
            <div className="feature-card" key={index}>
              <div className="feature-icon">{feature.icon}</div>
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeatureSection;
