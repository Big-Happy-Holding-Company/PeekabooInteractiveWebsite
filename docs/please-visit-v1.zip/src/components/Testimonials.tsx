
import React from 'react';
import './Testimonials.css';

const testimonials = [
  {
    quote: "These apps have become essential for our bedtime routine. My toddler is calmer and falls asleep much easier now.",
    author: "Sarah M., Parent"
  },
  {
    quote: "As an early childhood educator, I appreciate the thoughtful design. These apps respect children's natural curiosity.",
    author: "James L., Preschool Teacher"
  },
  {
    quote: "Finally, an app that doesn't overstimulate my sensory-sensitive child. The gentle interactions are perfect.",
    author: "Priya K., Parent"
  }
];

const Testimonials: React.FC = () => {
  return (
    <section className="testimonials">
      <div className="container">
        <h2 className="section-title">What Parents and Educators Say</h2>
        <p className="section-subtitle">
          Trusted by families and professionals for calm, educational play
        </p>
        
        <div className="testimonial-cards">
          {testimonials.map((testimonial, index) => (
            <div className="testimonial-card" key={index}>
              <div className="quote">“{testimonial.quote}”</div>
              <div className="author">— {testimonial.author}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
