
import React from 'react';
import HeroSection from './components/HeroSection';
import FeatureSection from './components/FeatureSection';
import AppShowcase from './components/AppShowcase';
import Testimonials from './components/Testimonials';
import DownloadSection from './components/DownloadSection';
import Footer from './components/Footer';
import './App.css';

function App() {
  return (
    <div className="App">
      <HeroSection />
      <FeatureSection />
      <AppShowcase />
      <Testimonials />
      <DownloadSection />
      <Footer />
    </div>
  );
}

export default App;
