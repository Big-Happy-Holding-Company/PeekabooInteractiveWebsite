
import React from 'react';
import './App.css';
import Hero from './components/Hero';
import AppsOverview from './components/AppsOverview';
import Features from './components/Features';
import WhyPeekaboo from './components/WhyPeekaboo';
import Footer from './components/Footer';

function App() {
  return (
    <div className="App">
      <Hero />
      <AppsOverview />
      <Features />
      <WhyPeekaboo />
      <Footer />
    </div>
  );
}

export default App;
