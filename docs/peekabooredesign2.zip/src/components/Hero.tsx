
import React from 'react';
import './Hero.css';

const Hero: React.FC = () => {
  return (
    <section className="hero">
      <div className="hero-content">
        <div className="hero-text">
          <h1 className="hero-title">
            Discover Gentle Play with Peekaboo
          </h1>
          <p className="hero-subtitle">
            Calming, educational apps for toddlers 0–4. Gentle interactive physics dioramas that invite peaceful discovery at your child's pace.
          </p>
          <div className="hero-buttons">
            <a
              href="https://apps.apple.com/us/app/peekaboo-calm/id6748668506?uo=2"
              className="app-store-button calm-button"
              target="_blank"
              rel="noopener noreferrer"
            >
              Get Peekaboo Calm
            </a>
            <a
              href="https://apps.apple.com/us/app/peekaboo-plunk/id6749132469?uo=2"
              className="app-store-button plunk-button"
              target="_blank"
              rel="noopener noreferrer"
            >
              Get Peekaboo Plunk
            </a>
          </div>
        </div>
        <div className="hero-visual">
          <div className="floating-elements">
            <div className="element cloud"></div>
            <div className="element leaf"></div>
            <div className="element bubble"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
