
import React from 'react';
import './WhyPeekaboo.css';

const WhyPeekaboo: React.FC = () => {
  return (
    <section className="why-peekaboo">
      <div className="container">
        <h2 className="section-title">For Sensory-Sensitive Kids & Families</h2>
        <p className="section-subtitle">
          Thoughtfully crafted for toddlers 0–4, Peekaboo turns small taps into gentle, delightful play. Like a modern see-and-say, each app fosters quiet exploration without overwhelm.
        </p>
        <div className="why-content">
          <div className="why-text">
            <p>
              We believe in simplicity and calm. No rushing, no competition—just pure, joyful moments that build confidence through discovery. Parents love how easy it is to co-play, turning screen time into shared, soothing experiences.
            </p>
            <div className="cta-buttons">
              <a
                href="https://apps.apple.com/us/app/peekaboo-calm/id6748668506?uo=2"
                className="cta-button calm-cta"
                target="_blank"
                rel="noopener noreferrer"
              >
                Try Peekaboo Calm
              </a>
              <a
                href="https://apps.apple.com/us/app/peekaboo-plunk/id6749132469?uo=2"
                className="cta-button plunk-cta"
                target="_blank"
                rel="noopener noreferrer"
              >
                Try Peekaboo Plunk
              </a>
            </div>
          </div>
          <div className="why-visual">
            <div className="gentle-wave"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyPeekaboo;
