
import React from 'react';
import './Features.css';

const Features: React.FC = () => {
  return (
    <section className="features">
      <div className="container">
        <h2 className="section-title">What Makes Peekaboo Special</h2>
        <div className="features-grid">
          <div className="feature-item">
            <div className="feature-icon tap-icon"></div>
            <h3>Gentle Interactions</h3>
            <p>One-tap play with large touch areas for little hands. Soft sounds and soothing colors create peaceful discovery.</p>
          </div>
          <div className="feature-item">
            <div className="feature-icon voice-icon"></div>
            <h3>Record Your Own Voice</h3>
            <p>Add a familiar hello from parents, grandparents, or siblings. Personalize play to make it feel cozy and close.</p>
          </div>
          <div className="feature-item">
            <div className="feature-icon no-ads-icon"></div>
            <h3>No Distractions</h3>
            <p>Free from ads, scores, timers, or pressure. Just quiet cause-and-effect moments in a safe, sensory-friendly space.</p>
          </div>
          <div className="feature-item">
            <div className="feature-icon routine-icon"></div>
            <h3>Perfect for Routines</h3>
            <p>Designed for bedtime wind-downs, transitions, and on-the-go breaks. Short, cozy sessions for everyday calm.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
