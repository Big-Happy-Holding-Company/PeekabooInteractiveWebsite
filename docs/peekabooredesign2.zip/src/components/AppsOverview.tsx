
import React from 'react';
import './AppsOverview.css';

const AppsOverview: React.FC = () => {
  return (
    <section className="apps-overview">
      <div className="container">
        <h2 className="section-title">Meet Peekaboo Calm & Plunk</h2>
        <p className="section-subtitle">
          These are not games—they're gentle, interactive experiences designed for little ones to explore at their own pace.
        </p>
        <div className="apps-grid">
          <div className="app-card calm-card">
            <div className="app-icon calm-icon"></div>
            <h3>Peekaboo Calm</h3>
            <p>
              A soothing underwater world where taps reveal soft surprises. Perfect for bedtime wind-downs and quiet moments.
            </p>
            <a
              href="https://apps.apple.com/us/app/peekaboo-calm/id6748668506?uo=2"
              className="download-button"
              target="_blank"
              rel="noopener noreferrer"
            >
              Download Now
            </a>
          </div>
          <div className="app-card plunk-card">
            <div className="app-icon plunk-icon"></div>
            <h3>Peekaboo Plunk</h3>
            <p>
              A cozy forest diorama with gentle plunks and peeks. Ideal for transitions and on-the-go sensory breaks.
            </p>
            <a
              href="https://apps.apple.com/us/app/peekaboo-plunk/id6749132469?uo=2"
              className="download-button"
              target="_blank"
              rel="noopener noreferrer"
            >
              Download Now
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AppsOverview;
