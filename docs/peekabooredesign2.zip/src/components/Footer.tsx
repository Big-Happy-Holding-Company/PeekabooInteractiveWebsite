
import React from 'react';
import './Footer.css';

const Footer: React.FC = () => {
  return (
    <footer className="footer">
      <div className="container">
        <p>&copy; 2025 Peekaboo Interactive. Made with love for little explorers.</p>
        <div className="footer-links">
          <a
            href="https://apps.apple.com/us/developer/bhhc-llc/id1808485512"
            target="_blank"
            rel="noopener noreferrer"
          >
            View Developer on App Store
          </a>
          <a href="https://peekaboointeractive.com" target="_blank" rel="noopener noreferrer">
            peekaboointeractive.com
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
